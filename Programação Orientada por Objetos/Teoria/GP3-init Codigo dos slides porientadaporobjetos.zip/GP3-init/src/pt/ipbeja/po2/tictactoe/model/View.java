package pt.ipbeja.po2.tictactoe.model;

public interface View {

    void disablePosition(int line, int col);
}

