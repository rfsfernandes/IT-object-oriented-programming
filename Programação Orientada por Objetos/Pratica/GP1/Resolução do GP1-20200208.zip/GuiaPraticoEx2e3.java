/**
 * Created by DiogoPM on 07/03/2018.
 */


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class GuiaPraticoEx2e3 extends Application {

    private Button btn1;
    private Button btn2;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        // Ver GuiaPraticoEx1
        ButtonHandler handler = new ButtonHandler();

        // VBox é um container que dispõe o seu conteúdo de forma linear e Vertical (já a HBox -> Horizontal Box)
        // Estes elementos são qualquer objecto de uma class que extenda Node (ver http://cms.ipbeja.pt/mod/url/view.php?id=130016)
        VBox vBox = new VBox();

        this.btn1 = new Button("Button 1");
        this.btn2 = new Button("Button 2");

        this.btn1.setOnAction(handler);
        this.btn2.setOnAction(handler);

        // Para adicionar elementos a uma VBox, temos de obter a lista dos seus elementos e adicionar-lhe o novo elemento
        // Obtemos essa lista com o método getChildren(), para adicionar um elemento podemos utilizar o método add(Node e)
        // ou, alternativamente, se quisermos adicionar mais que um elemento de uma só vez, o método addAll(Node... element).
        // (pode ler sobre varargs em Java em relação ao tipo de parâmetros Object... como é usado no método addAll)

        // Exemplo addAll: Passamos como argumentos todos os elementos, por ordem e separados por vírgulas
        vBox.getChildren().addAll(this.btn1, this.btn2);

        // Exemplo add: Só podemos passar um elemento em cada chamada deste método.
        // Comentar a linha acima e descomentar as 2 linhas abaixo para verificar que se obtém o mesmo resultado
        //vBox.getChildren().add(btn1);
        //vBox.getChildren().add(btn2);


        Scene scene = new Scene(vBox);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    class ButtonHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {

            // No objecto ActionEvent, vem a informação sobre qual o elemento que gerou o evento.
            // Podemos obter o objecto que gerou o evento através do método getSource()
            // Este método devolve um Object e neste caso, como sabemos que a fonte do evento é um Button,
            // podemos "transformar" esse Object num Button através de um cast.
            Button button = (Button) event.getSource();
            System.out.println(button.getText());

            Alert alert;

            if (button == btn1) {
                alert = new Alert(Alert.AlertType.INFORMATION, "Button 1");
            } else {
                alert = new Alert(Alert.AlertType.ERROR, "Button 2");
            }

            alert.showAndWait();

        }
    }
}
