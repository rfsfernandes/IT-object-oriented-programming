/**
 * Created by DiogoPM on 07/03/2018.
 */


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class GuiaPraticoEx4 extends Application {


    // Criamos as nossas variáveis de contagem como membros desta class
    private int leftCounter;
    private int rightCounter;

    // Criamos as variáveis das Labels e Buttons (neste momento não estão inicializadas! a inicialização é feita no método start)
    private Label leftLabel;
    private Label rightLabel;
    private Button leftBtn;
    private Button rightBtn;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        // Ver exercícios anteriores
        ButtonHandler handler = new ButtonHandler();

        /**
         * Layout a desenhar
         *  ___________________________
         * |HBox                       |
         * | ____________ ____________ |
         * | |Vbox      | |Vbox      | |
         * | |          | |          | |
         * | |  LABEL   | |  LABEL   | |
         * | |  BUTTON  | |  BUTTON  | |
         * | |__________| |__________| |
         * |___________________________|
         */

        /**
         * HBox contém:
         *  -- VBox contém:
         *      -> Label
         *      -> Button
         *  -- VBox contém:
         *      -> Label
         *      -> Button
         */

        HBox root = new HBox();
        VBox leftBox = new VBox();
        VBox rightBox = new VBox();

        this.leftLabel = new Label("0"); // Podemos criar os objectos Label com o texto inicial "0"
        this.rightLabel = new Label("0");

        this.leftBtn = new Button("Left button");
        this.rightBtn = new Button("Right button");

        this.leftBtn.setOnAction(handler);
        this.rightBtn.setOnAction(handler);

        // Adicionamos os elementos às VBox respectivas
        leftBox.getChildren().addAll(this.leftLabel, this.leftBtn);
        rightBox.getChildren().addAll(this.rightLabel, this.rightBtn);

        // Por fim, adicionamos as duas VBox à HBox que é a raíz do nosso layout
        root.getChildren().addAll(leftBox, rightBox);

        Scene scene = new Scene(root); // Colocamos como raíz da Scene, o nosso layout raíz
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    class ButtonHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Button button = (Button) event.getSource();

            // Como temos os Buttons como membros/campos da class GuiaPraticoEx4, temos acesso a eles
            // Podemos então verificar qual dos botões foi pressionado, comparando o botão fonte do do evento com os
            // botões que criámos
            if (button == leftBtn) {

                // Para colocar um novo texto nas Labels, usamos o método setText(String value)
                // Incrementamos a nossa variável de contagem e colocamos esse valor na label (podemos concatenar um
                // número com uma String vazia -> "". Por ex: "" + 2 => "2", 5.5 + "" => "5.5")
                leftLabel.setText(++leftCounter + ""); // Ver a diferença entre ++leftCounter e leftCounter++. O que acontece?
            } else if (button == rightBtn) {
                rightLabel.setText(++rightCounter + "");
            }

        }
    }


}









