/**
 * Created by DiogoPM on 07/03/2018.
 */


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class GuiaPraticoEx1 extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {

        // Criar o objecto que lida com os eventos do botão (implementa EventHandler<ActionEvent>)
        ButtonHandler handler = new ButtonHandler();

        // Criar o botão com título "Press me"
        Button button = new Button("Press me");

        // Atribuir o EventHandler ao botão.
        // Quando o botão for pressionado, o método handle da class ButtonHandler será invocado
        button.setOnAction(handler); // o método setOnAction recebe como parâmetro uma instância de uma class que implemente EventHandler<ActionEvent>

        Scene scene = new Scene(button);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    class ButtonHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            // Cada vez que o botão for pressionado, este método é invocado


            System.out.println("Button clicked!");
            Alert alert = new Alert(Alert.AlertType.ERROR, "Hello!"); // Criamos uma janela de erro
            alert.showAndWait(); // Temos de mostrar o alerta explicitamente

        }
    }
}
