package pt.ipbeja.po2.tictactoe;

import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * Button for the tic tac toe board. Includes an ImageView for holding button images and a method for evaluating players' turns.
 */
public class TicTacToeButton extends Button {
    private ImageView imageView;

    /**
     * Constructor. Initialises a button with an image.
     */
    public TicTacToeButton() {
        this.imageView = new ImageView(new Image("/res/noplayer.png"));
        this.setGraphic(this.imageView);
    }

    /**
     * Executes a turn on behalf of a player and updates the button image.
     * @param turn Turn number.
     */
    public void play(int turn) {
        switch (turn % 2) {
            case 1:
                this.imageView = new ImageView(new Image("/res/player1.png"));
                break;
            case 0:
                this.imageView = new ImageView(new Image("/res/player2.png"));
                break;
        }
        this.setGraphic(this.imageView);
    }
}
