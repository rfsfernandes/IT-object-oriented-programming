package pt.ipbeja.po2.tictactoe;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;

/**
 * Class to hold the board of a game of tic tac toe.
 * @author Sascha Geng
 */
public class TicTacToeBoardEx1to8 extends GridPane {
    public static final int SIZE = 3;

    /**
     * Constructor. Only calls the board creation method.
     */
    public TicTacToeBoardEx1to8() {
        this.createBoard();
    }

    /**
     * Populates the board with a square grid of buttons.
     */
    private void createBoard() {
        ButtonHandler buttonHandler = new ButtonHandler();
        for (int line = 0; line < SIZE; line++) {
            for (int col = 0; col < SIZE; col++) {
                Button button = new Button(line + ", " + col);
                button.setOnAction(buttonHandler);
                button.setPrefSize(100, 100);
                button.setMaxSize(100, 100);
                this.add(button, col, line);
            }
        }
    }

    /**
     * Inner class for button click handling.
     */
    private class ButtonHandler implements EventHandler<ActionEvent> {
        /**
         * Event handler. Changes state of the button from empty (or the initial coordinate string) to X to O in a circular pattern.
         * @param event the event that occurred.
         */
        @Override
        public void handle(ActionEvent event) {
            Button button = (Button) event.getSource();
            switch (button.getText()) {
                case "X":
                    button.setText("O");
                    break;
                case "O":
                    button.setText("");
                    break;
                default:
                    button.setText("X");
            }
        }
    }
}
