package pt.ipbeja.po2.tictactoe;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class TicTacToeStart extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {
        // change the following line to use different versions of the board
        TicTacToeBoardEx11to13 board = new TicTacToeBoardEx11to13();
        Scene scene = new Scene(board);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        Application.launch(args);
    }
}
