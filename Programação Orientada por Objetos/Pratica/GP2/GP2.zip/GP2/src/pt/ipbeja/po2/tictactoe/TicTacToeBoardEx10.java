package pt.ipbeja.po2.tictactoe;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

/**
 * Class to hold the board of a game of tic tac toe.
 * @author Sascha Geng
 */
public class TicTacToeBoardEx10 extends GridPane {
    private static final int SIZE = 3;
    private int turnCounter = 0;

    /**
     * Constructor. Only calls the board creation method.
     */
    public TicTacToeBoardEx10() {
        this.createBoard();
    }

    /**
     * Populates the board with a square grid of buttons.
     */
    private void createBoard() {
        ButtonHandler buttonHandler = new ButtonHandler();
        for (int line = 0; line < SIZE; line++) {
            for (int col = 0; col < SIZE; col++) {
                ImageView imageView = new ImageView(new Image("/res/noplayer.png"));
                TicTacToeButton button = new TicTacToeButton();
                button.setGraphic(imageView);
                button.setOnAction(buttonHandler);
                this.add(button, col, line);
            }
        }
    }

    /**
     * Inner class for button click handling.
     */
    private class ButtonHandler implements EventHandler<ActionEvent> {
        /**
         * Event handler. Changes state of the button from empty (or the initial coordinate string) to X to O in a circular pattern.
         * @param event the event that occurred.
         */
        @Override
        public void handle(ActionEvent event) {
            turnCounter++;
            Button button = (Button) event.getSource();

            if (turnCounter % 2 == 1) {
                button.setGraphic(new ImageView(new Image("/res/player1.png")));
            } else {
                button.setGraphic(new ImageView(new Image("/res/player2.png")));
            }
        }
    }
}
