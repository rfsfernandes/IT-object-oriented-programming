package pt.ipbeja.po2.tictactoe;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

import static java.lang.System.exit;

/**
 * Class to hold the board of a game of tic tac toe.
 * @author Sascha Geng
 */
public class TicTacToeBoardEx11to13 extends GridPane {
    private static final int SIZE = 3;
    private int turnCounter = 0;

    /**
     * Constructor. Only calls the board creation method.
     */
    public TicTacToeBoardEx11to13() {
        this.createBoard();
    }

    /**
     * Populates the board with a square grid of buttons.
     */
    private void createBoard() {
        for (int line = 0; line < SIZE; line++) {
            for (int col = 0; col < SIZE; col++) {
                ButtonHandler buttonHandler = new ButtonHandler();
                TicTacToeButton button = new TicTacToeButton();
                button.setOnAction(buttonHandler);
                this.add(button, col, line);
            }
        }
    }

    /**
     * Inner class for button click handling.
     */
    private class ButtonHandler implements EventHandler<ActionEvent> {
        /**
         * Event handler. Passes the turn number to the button for evaluation of the player and quits after 9 turns.
         * @param event the event that occurred.
         */
        @Override
        public void handle(ActionEvent event) {
            turnCounter++;
            TicTacToeButton button = (TicTacToeButton) event.getSource();
            button.play(turnCounter);
            button.setDisable(true);

            if (turnCounter == 9) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION, "Game over!");
                alert.showAndWait();
                exit(0);
            }
        }
    }
}
