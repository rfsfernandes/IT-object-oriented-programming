package pt.ipbeja.po2.tictactoe.gui;


import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.GridPane;

/**
 * Created by DiogoPM on 14/03/2018.
 */

public class TicTacToeBoard extends GridPane {

    private static final int SIZE = 3;

    public TicTacToeBoard() {

        this.createBoard();
    }

    /**
     * Creates the game board with a grid of TicTacToeButtons
     */
    private void createBoard() {

        TicTacToeButtonHandler handler = new TicTacToeButtonHandler();

        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                TicTacToeButton btn = new TicTacToeButton();
                btn.setOnAction(handler);
                this.add(btn, j, i);
            }
        }
    }


    /**
     * Click handler for the TicTacToeButtons
     */
    class TicTacToeButtonHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {

            TicTacToeButton button = (TicTacToeButton) event.getSource();


        }
    }


}