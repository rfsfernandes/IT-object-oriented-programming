package pt.ipbeja.po2.tictactoe;

import pt.ipbeja.po2.tictactoe.model.Place;

/**
 * @author DiogoPM
 * @version 11/04/2018
 */

public interface View {

    void draw();

    void playerWins(int player);

    void update(Place place, int line, int col);
}
