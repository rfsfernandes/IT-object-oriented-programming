package pt.ipbeja.po2.tictactoe;

/**
 * @author DiogoPM
 * @version 11/04/2018
 */

public interface View {

    void draw();

    void playerWins(int player);
}
