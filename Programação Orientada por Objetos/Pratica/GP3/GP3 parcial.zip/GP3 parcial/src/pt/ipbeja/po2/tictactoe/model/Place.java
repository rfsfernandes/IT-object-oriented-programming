package pt.ipbeja.po2.tictactoe.model;

/**
 * @author Sascha Geng, Diogo Pina Manique
 * @version 24-05-2018
 */

public enum Place {
    X,
    O,
    EMPTY
}
