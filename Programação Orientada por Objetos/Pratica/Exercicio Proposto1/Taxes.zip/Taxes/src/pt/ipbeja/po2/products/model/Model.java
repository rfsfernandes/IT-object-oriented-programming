package pt.ipbeja.po2.products.model;

import java.util.ArrayList;
import java.util.List;

public class Model {
    private List<Taxable> allTaxedProducts;

    public Model()
    {
        this.allTaxedProducts = new ArrayList<>();
        this.allTaxedProducts.add(new Simple(10));
        this.allTaxedProducts.add(new Extra(1000));
        this.allTaxedProducts.add(new Super(500));
        this.allTaxedProducts.add(new Super(1000));
        this.allTaxedProducts.add(new Extra(50));
    }

    public String allPricesWithTax()
    {
        String s = "";
        for(Taxable taxed : this.allTaxedProducts)
        {
            s += taxed.priceWithTaxes() + ", ";
        }
        return s.substring(0, s.length() - 2);
    }

//    // melhor por ser mais rápido o que é mais  importante em listas mais longas
//    public String allPricesWithTax()
//    {
//        StringBuilder s = new StringBuilder();
//        for(Taxable taxed : this.allTaxedProducts)
//        {
//            s.append(taxed.priceWithTaxes()).append(", ");
//        }
//        return s.substring(0, s.length() - 2);
//    }

    public double totalPrice()
    {
        double total = 0;
        for(Taxable taxed : this.allTaxedProducts)
        {
            total += taxed.priceWithTaxes();
        }
        return total;
    }
}
