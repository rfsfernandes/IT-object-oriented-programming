package pt.ipbeja.po2.products.model;

public class Simple implements Taxable {

    private int price;

    public Simple(int price) {

        this.price = price;
    }

    @Override
    public double priceWithTaxes() {
        return this.price * 1.1;
    }
}
