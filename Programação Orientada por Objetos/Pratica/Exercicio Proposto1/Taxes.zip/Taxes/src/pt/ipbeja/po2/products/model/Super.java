package pt.ipbeja.po2.products.model;

public class Super implements Taxable {

    private int price;

    Super(int price) {

        this.price = price;
    }

    @Override
    public double priceWithTaxes() {
        return this.price * 1.2;
    }
}
