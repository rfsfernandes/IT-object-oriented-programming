package pt.ipbeja.po2.products.model;

public class Extra implements Taxable {

    private int price;

    Extra(int price)
    {
        this.price = price;
    }

    @Override
    public double priceWithTaxes() {
        if (this.price < 100) {
            return this.price * 1.2;
        }
        else {
            return this.price * 1.25;
        }
    }

//    @Override
//    public double priceWithTaxes() {
//        return this.price * ((this.price < 100) ? 1.2 : 1.25);
//    }
}
