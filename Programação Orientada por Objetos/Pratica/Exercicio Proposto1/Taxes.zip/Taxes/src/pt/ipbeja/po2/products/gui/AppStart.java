package pt.ipbeja.po2.products.gui;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import pt.ipbeja.po2.products.model.Model;

public class AppStart extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        Button button = new Button("Get Prices");
        button.setOnAction(new ButtonHandler());

        primaryStage.setScene(new Scene(button));
        primaryStage.show();
    }

    class ButtonHandler implements EventHandler<ActionEvent> {

        @Override
        public void handle(ActionEvent event) {
            Model model = new Model();
            String message = model.allPricesWithTax() + "\n\ntotal = " + model.totalPrice();
            //System.out.println(message);
            Alert alert = new Alert(Alert.AlertType.INFORMATION, message);
            alert.show();
        }
    }

}
