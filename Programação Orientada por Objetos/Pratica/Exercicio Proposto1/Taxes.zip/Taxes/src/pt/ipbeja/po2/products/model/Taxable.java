package pt.ipbeja.po2.products.model;

public interface Taxable {
    double priceWithTaxes();
}
