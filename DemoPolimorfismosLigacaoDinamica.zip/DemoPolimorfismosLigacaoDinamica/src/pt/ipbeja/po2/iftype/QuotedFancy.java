package pt.ipbeja.po2.iftype;

import pt.ipbeja.po2.iftype.Quote;

/**
 * @author João Paulo Barros
 * @version 2020/05/12
 */

class QuotedFancy extends Quote {

    public QuotedFancy(String text, String author) {
        super(text, author);
    }
}
