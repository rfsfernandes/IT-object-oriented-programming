package pt.ipbeja.po2.iftype;

/**
 * @author João Paulo Barros
 * @version 2020/05/12
 */

interface Quotable {
    String text();

    String author();

}
