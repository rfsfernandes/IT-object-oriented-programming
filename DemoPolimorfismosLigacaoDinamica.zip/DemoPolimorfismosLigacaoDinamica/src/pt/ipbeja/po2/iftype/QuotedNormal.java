package pt.ipbeja.po2.iftype;

import pt.ipbeja.po2.iftype.Quote;

/**
 * @author João Paulo Barros
 * @version 2020/05/12
 */
class QuotedNormal extends Quote {

    public QuotedNormal(String text, String author) {
        super(text, author);
    }
}
